import React, { useState, useEffect } from 'react'
import { 
  FileText, Eye, CheckCircle, Upload, XCircle, BarChart3, Users, UserMinus, 
  Calendar, Download, Archive, Clock, AlertTriangle, Shield, Lock, 
  Trash2, RefreshCw, Globe, Server, Database, HardDrive, Zap, Award,
  FileCheck, FilePlus, FileX, User, Search, Filter, TrendingUp, MoreHorizontal,
  ChevronRight, Activity, FileDown, Printer, Share, Settings, Package, Target
} from 'lucide-react'
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, BarChart, Bar, AreaChart, Area } from 'recharts'

export default function DMSDashboard() {
  const [dateRange, setDateRange] = useState('last30days')
  const [departmentFilter, setDepartmentFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [searchTerm, setSearchTerm] = useState('')
  const [currentTime, setCurrentTime] = useState(new Date())

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  // Core dashboard metrics
  const dashboardData = {
    totalDocuments: 45680,
    uploadedDocs: 1200,
    indexed: 960,
    inQA: 80,
    exported: 650,
    failedToExport: 7850,
    totalPagesAllDocs: 2840560,
    
    // User metrics
    totalUsers: 545,
    activeUsers: 350,
    inactiveUsers: 120,
    disabledUsers: 75,
    
    // System metrics
    storageUsed: 2.4,
    storageTotal: 10,
    systemUptime: 99.8,
    securityViolations: 89,
    avgUploadSpeed: 12.5,
    avgSearchTime: 0.8,
    
    // Additional metrics
    approvedDocs: 8940,
    rejectedDocs: 234,
    archivedDocs: 2340,
    totalDownloads: 15670,
    
    // Batch processing metrics
    batchJobsTotal: 245,
    batchJobsCompleted: 210,
    batchJobsRunning: 15,
    batchJobsFailed: 20
  }

  // Chart data
  const documentStatusData = [
    { name: 'Approved', value: 8940, color: '#10B981' },
    { name: 'Rejected', value: 234, color: '#EF4444' },
    { name: 'In Review', value: 80, color: '#3B82F6' },
    { name: 'Archived', value: 2340, color: '#F59E0B' }
  ]

  const departmentData = [
    { name: 'HR', uploads: 4500, exports: 3200, color: '#06B6D4' },
    { name: 'Finance', uploads: 3800, exports: 2900, color: '#8B5CF6' },
    { name: 'IT', uploads: 8200, exports: 6800, color: '#10B981' },
    { name: 'Operations', uploads: 6100, exports: 4500, color: '#F59E0B' },
    { name: 'Sales', uploads: 5000, exports: 3800, color: '#EF4444' },
    { name: 'Legal', uploads: 2400, exports: 1900, color: '#EC4899' }
  ]

  const monthlyTrendData = [
    { month: 'Jan', uploads: 4200, exports: 3240, storage: 1.8, users: 520 },
    { month: 'Feb', uploads: 3800, exports: 3100, storage: 2.0, users: 525 },
    { month: 'Mar', uploads: 5200, exports: 4800, storage: 2.1, users: 535 },
    { month: 'Apr', uploads: 4780, exports: 4200, storage: 2.2, users: 540 },
    { month: 'May', uploads: 5100, exports: 4600, storage: 2.3, users: 545 },
    { month: 'Jun', uploads: 5400, exports: 5000, storage: 2.4, users: 545 }
  ]

  const weeklyActivityData = [
    { day: 'Mon', uploads: 180, searches: 1200, downloads: 450 },
    { day: 'Tue', uploads: 220, searches: 1450, downloads: 520 },
    { day: 'Wed', uploads: 190, searches: 1350, downloads: 480 },
    { day: 'Thu', uploads: 240, searches: 1600, downloads: 580 },
    { day: 'Fri', uploads: 280, searches: 1800, downloads: 620 },
    { day: 'Sat', uploads: 120, searches: 800, downloads: 280 },
    { day: 'Sun', uploads: 80, searches: 600, downloads: 190 }
  ]

  // PDF Export Function
  const exportToPDF = async () => {
    try {
      const printWindow = window.open('', '_blank')
      
      const htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>Document Management Dashboard Report</title>
          <style>
            body { 
              font-family: Arial, sans-serif; 
              margin: 20px; 
              background: white;
              color: black;
            }
            .header { 
              text-align: center; 
              margin-bottom: 30px; 
              border-bottom: 2px solid #333;
              padding-bottom: 20px;
            }
            .metric-grid { 
              display: grid; 
              grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
              gap: 20px; 
              margin: 20px 0; 
            }
            .metric-card { 
              border: 1px solid #ddd; 
              padding: 15px; 
              border-radius: 8px;
              background: #f9f9f9;
            }
            .metric-title { 
              font-size: 14px; 
              color: #666; 
              margin-bottom: 10px;
              font-weight: bold;
            }
            .metric-item { 
              display: flex; 
              justify-content: space-between; 
              margin-bottom: 8px;
            }
            .section { 
              margin: 30px 0; 
              page-break-inside: avoid;
            }
            .section h2 {
              border-bottom: 1px solid #333;
              padding-bottom: 10px;
              color: #333;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Document Management System</h1>
            <h2>Analytics & Control Center Report</h2>
            <p>Generated on: ${currentTime.toLocaleDateString()} at ${currentTime.toLocaleTimeString()}</p>
          </div>

          <div class="section">
            <h2>Document Processing Overview</h2>
            <div class="metric-grid">
              <div class="metric-card">
                <div class="metric-title">Document Processing</div>
                <div class="metric-item"><span>Uploaded</span><span>${dashboardData.uploadedDocs.toLocaleString()}</span></div>
                <div class="metric-item"><span>Indexed</span><span>${dashboardData.indexed.toLocaleString()}</span></div>
                <div class="metric-item"><span>In QA</span><span>${dashboardData.inQA.toLocaleString()}</span></div>
                <div class="metric-item"><span>Total Pages</span><span>${dashboardData.totalPagesAllDocs.toLocaleString()}</span></div>
              </div>
              <div class="metric-card">
                <div class="metric-title">User Activity</div>
                <div class="metric-item"><span>Active Users</span><span>${dashboardData.activeUsers.toLocaleString()}</span></div>
                <div class="metric-item"><span>Inactive Users</span><span>${dashboardData.inactiveUsers.toLocaleString()}</span></div>
                <div class="metric-item"><span>Disabled Users</span><span>${dashboardData.disabledUsers.toLocaleString()}</span></div>
                <div class="metric-item"><span>Total Users</span><span>${dashboardData.totalUsers.toLocaleString()}</span></div>
              </div>
              <div class="metric-card">
                <div class="metric-title">System Performance</div>
                <div class="metric-item"><span>Storage Used</span><span>${dashboardData.storageUsed}TB / ${dashboardData.storageTotal}TB</span></div>
                <div class="metric-item"><span>System Uptime</span><span>${dashboardData.systemUptime}%</span></div>
                <div class="metric-item"><span>Security Incidents</span><span>${dashboardData.securityViolations}</span></div>
                <div class="metric-item"><span>Avg Upload Speed</span><span>${dashboardData.avgUploadSpeed}MB/s</span></div>
              </div>
            </div>
          </div>
        </body>
        </html>
      `
      
      printWindow.document.write(htmlContent)
      printWindow.document.close()
      
      setTimeout(() => {
        printWindow.focus()
        printWindow.print()
      }, 500)

    } catch (error) {
      console.error('Export failed:', error)
      alert('Export failed. Please try again.')
    }
  }

  // Grouped Metric Card Component
  const GroupedMetricCard = ({ title, metrics, icon: Icon, color = "blue", onClick }) => {
    const colorClasses = {
      blue: "from-blue-500/10 to-blue-600/20 border-blue-500/30 hover:border-blue-400/50",
      green: "from-green-500/10 to-green-600/20 border-green-500/30 hover:border-green-400/50",
      yellow: "from-yellow-500/10 to-yellow-600/20 border-yellow-500/30 hover:border-yellow-400/50",
      red: "from-red-500/10 to-red-600/20 border-red-500/30 hover:border-red-400/50",
      purple: "from-purple-500/10 to-purple-600/20 border-purple-500/30 hover:border-purple-400/50",
      cyan: "from-cyan-500/10 to-cyan-600/20 border-cyan-500/30 hover:border-cyan-400/50"
    }

    const iconColors = {
      blue: "text-blue-400",
      green: "text-green-400", 
      yellow: "text-yellow-400",
      red: "text-red-400",
      purple: "text-purple-400",
      cyan: "text-cyan-400"
    }

    return (
      <div 
        className={`relative bg-gradient-to-br ${colorClasses[color]} border rounded-2xl p-6 backdrop-blur-sm hover:shadow-2xl transition-all duration-300 group hover:scale-102 cursor-pointer`}
        onClick={onClick}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-white/[0.03] to-transparent opacity-60 rounded-2xl"></div>
        
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className={`p-3 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 group-hover:bg-white/20 transition-all duration-300`}>
                <Icon className={`w-6 h-6 ${iconColors[color]}`} />
              </div>
              <h3 className="text-lg font-semibold text-white">{title}</h3>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors" />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            {metrics.map((metric, index) => (
              <div key={index} className="bg-white/5 rounded-xl p-4 border border-white/10">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-gray-300 uppercase tracking-wider">{metric.label}</span>
                  {metric.icon && <metric.icon className="w-4 h-4 text-gray-400" />}
                </div>
                <div className="text-xl font-bold text-white mb-1">
                  {typeof metric.value === 'number' ? metric.value.toLocaleString() : metric.value}
                </div>
                {metric.change && (
                  <div className="flex items-center text-xs">
                    <span className={`font-semibold ${metric.changeType === 'positive' ? 'text-green-400' : 'text-red-400'}`}>
                      {metric.changeType === 'positive' ? '+' : ''}{metric.change}
                    </span>
                    <span className="text-gray-400 ml-1">vs yesterday</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  const refreshData = () => {
    alert('Refreshing dashboard data...')
  }

  const handleDocumentProcessing = () => {
    alert('Opening Document Processing Console...\n\n• Uploaded: ' + dashboardData.uploadedDocs + '\n• Indexed: ' + dashboardData.indexed + '\n• In QA: ' + dashboardData.inQA + '\n• Total Pages: ' + dashboardData.totalPagesAllDocs.toLocaleString())
  }

  const handleUserActivity = () => {
    alert('Opening User Management Console...\n\n• Active Users: ' + dashboardData.activeUsers + '\n• Inactive Users: ' + dashboardData.inactiveUsers + '\n• Disabled Users: ' + dashboardData.disabledUsers + '\n• Total Users: ' + dashboardData.totalUsers)
  }

  const handleBatchProcessing = () => {
    alert('Opening Batch Processing Console...\n\n• Total Jobs: ' + dashboardData.batchJobsTotal + '\n• Completed: ' + dashboardData.batchJobsCompleted + '\n• Running: ' + dashboardData.batchJobsRunning + '\n• Failed: ' + dashboardData.batchJobsFailed)
  }

  const handleSystemPerformance = () => {
    alert('Opening System Performance Console...\n\n• Storage Used: ' + dashboardData.storageUsed + 'TB / ' + dashboardData.storageTotal + 'TB\n• System Uptime: ' + dashboardData.systemUptime + '%\n• Security Incidents: ' + dashboardData.securityViolations + '\n• Avg Upload Speed: ' + dashboardData.avgUploadSpeed + 'MB/s')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-gray-900 to-black text-white">
      {/* Background decoration */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-blue-500/3 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 w-full p-6 lg:p-8">
        {/* Header Section */}
        <div className="mb-10">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold bg-gradient-to-r from-white via-gray-100 to-gray-300 bg-clip-text text-transparent mb-4">
                Document Management
              </h1>
              <p className="text-xl sm:text-2xl text-gray-300 mb-2">Analytics & Control Center</p>
              <p className="text-sm text-gray-400">
                Last updated: {currentTime.toLocaleString()}
              </p>
            </div>
            
            {/* Search and Actions */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="search"
                  placeholder="Search documents..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-3 bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl focus:ring-2 focus:ring-blue-500/50 focus:border-transparent text-white placeholder-gray-400 w-full sm:w-80 transition-all"
                />
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={refreshData}
                  className="px-6 py-3 bg-gray-700/50 hover:bg-gray-700 text-white rounded-xl font-medium transition-all duration-200 flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  Refresh
                </button>
                <button 
                  onClick={exportToPDF}
                  className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-medium hover:from-blue-700 hover:to-purple-700 transition-all duration-200 shadow-lg flex items-center gap-2"
                >
                  <FileDown className="w-4 h-4" />
                  Export
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="mb-10">
          <div className="bg-gray-800/40 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-6">
            <div className="flex flex-wrap items-center gap-6">
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-gray-400" />
                <select 
                  value={dateRange}
                  onChange={(e) => setDateRange(e.target.value)}
                  className="px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl focus:ring-2 focus:ring-blue-500/50 text-white text-sm min-w-36"
                >
                  <option value="today">Today</option>
                  <option value="last7days">Last 7 Days</option>
                  <option value="last30days">Last 30 Days</option>
                  <option value="last90days">Last 90 Days</option>
                  <option value="last6months">Last 6 Months</option>
                </select>
              </div>
              
              <select 
                value={departmentFilter}
                onChange={(e) => setDepartmentFilter(e.target.value)}
                className="px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl focus:ring-2 focus:ring-blue-500/50 text-white text-sm min-w-40"
              >
                <option value="all">All Departments</option>
                <option value="hr">Human Resources</option>
                <option value="finance">Finance</option>
                <option value="it">IT</option>
                <option value="operations">Operations</option>
                <option value="sales">Sales</option>
                <option value="legal">Legal</option>
              </select>
              
              <select 
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl focus:ring-2 focus:ring-blue-500/50 text-white text-sm min-w-32"
              >
                <option value="all">All Status</option>
                <option value="approved">Approved</option>
                <option value="pending">Pending</option>
                <option value="review">Under Review</option>
                <option value="rejected">Rejected</option>
              </select>

              <button className="ml-auto px-4 py-3 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 rounded-xl font-medium transition-all duration-200 flex items-center gap-2 border border-blue-500/30">
                <Filter className="w-4 h-4" />
                Apply Filters
              </button>
            </div>
          </div>
        </div>

        {/* Grouped Metrics Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Document Processing Group */}
          <GroupedMetricCard
            title="Document Processing"
            icon={FileText}
            color="blue"
            onClick={handleDocumentProcessing}
            metrics={[
              { label: "Uploaded", value: dashboardData.uploadedDocs, change: "12%", changeType: "positive", icon: Upload },
              { label: "Indexed", value: dashboardData.indexed, icon: Eye },
              { label: "In QA", value: dashboardData.inQA, icon: CheckCircle },
              { label: "Total Pages", value: dashboardData.totalPagesAllDocs, icon: FileText }
            ]}
          />

          {/* User Activity Group */}
          <GroupedMetricCard
            title="User Activity"
            icon={Users}
            color="green"
            onClick={handleUserActivity}
            metrics={[
              { label: "Active Users", value: dashboardData.activeUsers, change: "5%", changeType: "positive", icon: User },
              { label: "Inactive Users", value: dashboardData.inactiveUsers, icon: Clock },
              { label: "Disabled Users", value: dashboardData.disabledUsers, icon: UserMinus },
              { label: "Total Users", value: dashboardData.totalUsers, icon: Users }
            ]}
          />

          {/* Batch Processing Group */}
          <GroupedMetricCard
            title="Batch Processing"
            icon={Package}
            color="purple"
            onClick={handleBatchProcessing}
            metrics={[
              { label: "Total Jobs", value: dashboardData.batchJobsTotal, icon: Package },
              { label: "Completed", value: dashboardData.batchJobsCompleted, change: "8%", changeType: "positive", icon: CheckCircle },
              { label: "Running", value: dashboardData.batchJobsRunning, icon: Activity },
              { label: "Failed", value: dashboardData.batchJobsFailed, icon: XCircle }
            ]}
          />

          {/* System Performance Group */}
          <GroupedMetricCard
            title="System Performance"
            icon={Server}
            color="cyan"
            onClick={handleSystemPerformance}
            metrics={[
              { label: "Storage Used", value: `${dashboardData.storageUsed}TB / ${dashboardData.storageTotal}TB`, icon: HardDrive },
              { label: "System Uptime", value: `${dashboardData.systemUptime}%`, icon: Activity },
              { label: "Security Incidents", value: dashboardData.securityViolations, icon: Shield },
              { label: "Upload Speed", value: `${dashboardData.avgUploadSpeed}MB/s`, icon: Zap }
            ]}
          />
        </div>

        {/* Large Charts Section */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mb-12">
          {/* Document Status Distribution - Large */}
          <div className="bg-gray-800/40 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-8">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-2xl font-semibold text-white">Document Status Distribution</h3>
              <button 
                onClick={() => alert('Viewing detailed document status breakdown with filtering options')}
                className="text-blue-400 hover:text-blue-300 text-sm font-medium px-4 py-2 bg-blue-500/10 rounded-lg border border-blue-500/30 transition-all"
              >
                View Details
              </button>
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={documentStatusData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={120}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {documentStatusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #374151',
                      borderRadius: '12px',
                      color: '#F9FAFB',
                      boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.3)'
                    }}
                  />
                  <Legend 
                    wrapperStyle={{ paddingTop: '20px' }}
                    iconType="circle"
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-6">
              {documentStatusData.map((item, index) => (
                <div key={index} className="flex items-center justify-between text-sm bg-white/5 rounded-lg p-3">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-4 h-4 rounded-full" 
                      style={{ backgroundColor: item.color }}
                    ></div>
                    <span className="text-gray-200 font-medium">{item.name}</span>
                  </div>
                  <span className="text-white font-semibold">{item.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Department Performance - Large */}
          <div className="bg-gray-800/40 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-8">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-2xl font-semibold text-white">Department Performance</h3>
              <button 
                onClick={() => alert('Opening department analytics with performance metrics and comparisons')}
                className="text-green-400 hover:text-green-300 text-sm font-medium px-4 py-2 bg-green-500/10 rounded-lg border border-green-500/30 transition-all"
              >
                Analyze
              </button>
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={departmentData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="name" 
                    stroke="#9CA3AF" 
                    fontSize={12}
                    angle={-45}
                    textAnchor="end"
                    height={80}
                    interval={0}
                  />
                  <YAxis stroke="#9CA3AF" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #374151',
                      borderRadius: '12px',
                      color: '#F9FAFB',
                      boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.3)'
                    }}
                  />
                  <Legend />
                  <Bar 
                    dataKey="uploads" 
                    name="Uploads" 
                    radius={[4, 4, 0, 0]}
                    fill="#3B82F6"
                  />
                  <Bar 
                    dataKey="exports" 
                    name="Exports" 
                    radius={[4, 4, 0, 0]}
                    fill="#10B981"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Large Trend Charts */}
        <div className="grid grid-cols-1 gap-8 mb-12">
          {/* Monthly Trends - Full Width Large */}
          <div className="bg-gray-800/40 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-8">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-2xl font-semibold text-white">6-Month Performance Trends</h3>
              <div className="flex gap-3">
                <button 
                  onClick={() => alert('Opening predictive analytics and trend forecasting')}
                  className="text-purple-400 hover:text-purple-300 text-sm font-medium px-4 py-2 bg-purple-500/10 rounded-lg border border-purple-500/30 transition-all"
                >
                  Forecast
                </button>
                <button 
                  onClick={() => alert('Exporting trend data to CSV format')}
                  className="text-gray-400 hover:text-gray-300 text-sm font-medium px-4 py-2 bg-gray-500/10 rounded-lg border border-gray-500/30 transition-all"
                >
                  Export Data
                </button>
              </div>
            </div>
            <div className="h-96">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyTrendData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="month" 
                    stroke="#9CA3AF" 
                    fontSize={12}
                  />
                  <YAxis stroke="#9CA3AF" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #374151',
                      borderRadius: '12px',
                      color: '#F9FAFB',
                      boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.3)'
                    }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="uploads" 
                    stroke="#3B82F6" 
                    strokeWidth={4}
                    dot={{ fill: '#3B82F6', strokeWidth: 3, r: 6 }}
                    activeDot={{ r: 8, stroke: '#3B82F6', strokeWidth: 2 }}
                    name="Document Uploads"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="exports" 
                    stroke="#10B981" 
                    strokeWidth={4}
                    dot={{ fill: '#10B981', strokeWidth: 3, r: 6 }}
                    activeDot={{ r: 8, stroke: '#10B981', strokeWidth: 2 }}
                    name="Document Exports"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="users" 
                    stroke="#F59E0B" 
                    strokeWidth={4}
                    dot={{ fill: '#F59E0B', strokeWidth: 3, r: 6 }}
                    activeDot={{ r: 8, stroke: '#F59E0B', strokeWidth: 2 }}
                    name="Active Users"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Weekly Activity Chart */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mb-12">
          <div className="bg-gray-800/40 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-8">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-2xl font-semibold text-white">Weekly Activity</h3>
              <button 
                onClick={() => alert('Opening weekly activity analysis with hourly breakdowns')}
                className="text-cyan-400 hover:text-cyan-300 text-sm font-medium px-4 py-2 bg-cyan-500/10 rounded-lg border border-cyan-500/30 transition-all"
              >
                Deep Dive
              </button>
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={weeklyActivityData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="day" 
                    stroke="#9CA3AF" 
                    fontSize={12}
                  />
                  <YAxis stroke="#9CA3AF" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #374151',
                      borderRadius: '12px',
                      color: '#F9FAFB',
                      boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.3)'
                    }}
                  />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="uploads" 
                    stackId="1"
                    stroke="#3B82F6" 
                    fill="#3B82F6"
                    fillOpacity={0.6}
                    name="Uploads"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="searches" 
                    stackId="2"
                    stroke="#10B981" 
                    fill="#10B981"
                    fillOpacity={0.6}
                    name="Searches"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="downloads" 
                    stackId="3"
                    stroke="#F59E0B" 
                    fill="#F59E0B"
                    fillOpacity={0.6}
                    name="Downloads"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Storage & Performance Metrics */}
          <div className="bg-gray-800/40 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-8">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-2xl font-semibold text-white">Storage & Performance</h3>
              <button 
                onClick={() => alert('Opening system diagnostics and performance monitoring')}
                className="text-yellow-400 hover:text-yellow-300 text-sm font-medium px-4 py-2 bg-yellow-500/10 rounded-lg border border-yellow-500/30 transition-all"
              >
                Diagnostics
              </button>
            </div>
            
            {/* Storage Usage Visual */}
            <div className="mb-8">
              <div className="flex justify-between items-center mb-3">
                <span className="text-gray-300 font-medium">Storage Usage</span>
                <span className="text-white font-semibold">{dashboardData.storageUsed}TB / {dashboardData.storageTotal}TB</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-4 overflow-hidden">
                <div 
                  className="h-4 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full transition-all duration-1000 ease-out"
                  style={{ width: `${(dashboardData.storageUsed / dashboardData.storageTotal) * 100}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-xs text-gray-400 mt-2">
                <span>0TB</span>
                <span>{dashboardData.storageTotal}TB</span>
              </div>
            </div>

            {/* Performance Metrics Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-4 h-4 text-green-400" />
                  <span className="text-sm text-gray-300">System Uptime</span>
                </div>
                <div className="text-2xl font-bold text-green-400">{dashboardData.systemUptime}%</div>
                <div className="text-xs text-gray-400">Last 30 days</div>
              </div>

              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-4 h-4 text-blue-400" />
                  <span className="text-sm text-gray-300">Upload Speed</span>
                </div>
                <div className="text-2xl font-bold text-blue-400">{dashboardData.avgUploadSpeed}MB/s</div>
                <div className="text-xs text-gray-400">Average</div>
              </div>

              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <div className="flex items-center gap-2 mb-2">
                  <Search className="w-4 h-4 text-purple-400" />
                  <span className="text-sm text-gray-300">Search Time</span>
                </div>
                <div className="text-2xl font-bold text-purple-400">{dashboardData.avgSearchTime}s</div>
                <div className="text-xs text-gray-400">Average</div>
              </div>

              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-4 h-4 text-red-400" />
                  <span className="text-sm text-gray-300">Security</span>
                </div>
                <div className="text-2xl font-bold text-red-400">{dashboardData.securityViolations}</div>
                <div className="text-xs text-gray-400">Incidents</div>
              </div>
            </div>
          </div>
        </div>

        {/* System Status Panel - Enhanced */}
        <div className="bg-gray-800/40 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-8 mb-12">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-2xl font-semibold text-white">Real-Time System Status</h3>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-green-400 font-medium">All Systems Operational</span>
              </div>
              <button 
                onClick={() => alert('Opening system health dashboard with detailed monitoring')}
                className="text-blue-400 hover:text-blue-300 text-sm font-medium px-4 py-2 bg-blue-500/10 rounded-lg border border-blue-500/30 transition-all"
              >
                Health Check
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-gradient-to-br from-green-500/10 to-green-600/20 rounded-xl p-6 border border-green-500/30">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Database className="w-6 h-6 text-green-400" />
                  <span className="text-white font-medium">Database</span>
                </div>
                <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
              </div>
              <div className="text-green-400 font-semibold text-lg mb-1">Online</div>
              <div className="text-sm text-gray-300 mb-2">Response: 12ms</div>
              <div className="text-xs text-gray-400">Connections: 245/500</div>
            </div>
            
            <div className="bg-gradient-to-br from-blue-500/10 to-blue-600/20 rounded-xl p-6 border border-blue-500/30">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <HardDrive className="w-6 h-6 text-blue-400" />
                  <span className="text-white font-medium">File Storage</span>
                </div>
                <div className="w-3 h-3 bg-blue-400 rounded-full animate-pulse"></div>
              </div>
              <div className="text-blue-400 font-semibold text-lg mb-1">Healthy</div>
              <div className="text-sm text-gray-300 mb-2">Free: {dashboardData.storageTotal - dashboardData.storageUsed}TB</div>
              <div className="text-xs text-gray-400">I/O: 850 ops/sec</div>
            </div>
            
            <div className="bg-gradient-to-br from-yellow-500/10 to-yellow-600/20 rounded-xl p-6 border border-yellow-500/30">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Package className="w-6 h-6 text-yellow-400" />
                  <span className="text-white font-medium">Processing</span>
                </div>
                <div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div>
              </div>
              <div className="text-yellow-400 font-semibold text-lg mb-1">Active</div>
              <div className="text-sm text-gray-300 mb-2">{dashboardData.batchJobsRunning} jobs running</div>
              <div className="text-xs text-gray-400">Queue: {dashboardData.inQA} pending</div>
            </div>
            
            <div className="bg-gradient-to-br from-purple-500/10 to-purple-600/20 rounded-xl p-6 border border-purple-500/30">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Globe className="w-6 h-6 text-purple-400" />
                  <span className="text-white font-medium">Search Index</span>
                </div>
                <div className="w-3 h-3 bg-purple-400 rounded-full animate-pulse"></div>
              </div>
              <div className="text-purple-400 font-semibold text-lg mb-1">Updated</div>
              <div className="text-sm text-gray-300 mb-2">Avg: {dashboardData.avgSearchTime}s</div>
              <div className="text-xs text-gray-400">Index size: 45.6GB</div>
            </div>
          </div>

          {/* System Health Bar */}
          <div className="mt-8 p-6 bg-white/5 rounded-xl border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-semibold text-white">Overall System Health</h4>
              <span className="text-2xl font-bold text-green-400">{dashboardData.systemUptime}%</span>
            </div>
            <div className="w-full bg-gray-600 rounded-full h-3 overflow-hidden">
              <div 
                className="h-3 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full transition-all duration-1000 ease-out"
                style={{ width: `${dashboardData.systemUptime}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-xs text-gray-400 mt-2">
              <span>0%</span>
              <span className="text-green-400 font-medium">Excellent Health</span>
              <span>100%</span>
            </div>
          </div>
        </div>

        {/* Quick Actions Panel */}
        <div className="bg-gray-800/40 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-8 mb-12">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-2xl font-semibold text-white">Quick Actions</h3>
            <button className="text-gray-400 hover:text-gray-300">
              <Settings className="w-5 h-5" />
            </button>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <button 
              onClick={() => alert('Opening bulk upload interface for multiple document processing')}
              className="bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 rounded-xl p-4 transition-all duration-200 group"
            >
              <Upload className="w-8 h-8 text-blue-400 mx-auto mb-3 group-hover:scale-110 transition-transform" />
              <div className="text-sm font-medium text-white">Bulk Upload</div>
              <div className="text-xs text-gray-400 mt-1">Upload multiple</div>
            </button>

            <button 
              onClick={() => alert('Opening batch export tool for mass document export')}
              className="bg-green-500/10 hover:bg-green-500/20 border border-green-500/30 rounded-xl p-4 transition-all duration-200 group"
            >
              <Download className="w-8 h-8 text-green-400 mx-auto mb-3 group-hover:scale-110 transition-transform" />
              <div className="text-sm font-medium text-white">Batch Export</div>
              <div className="text-xs text-gray-400 mt-1">Export selected</div>
            </button>

            <button 
              onClick={() => alert('Opening user management console for user administration')}
              className="bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 rounded-xl p-4 transition-all duration-200 group"
            >
              <Users className="w-8 h-8 text-purple-400 mx-auto mb-3 group-hover:scale-110 transition-transform" />
              <div className="text-sm font-medium text-white">Manage Users</div>
              <div className="text-xs text-gray-400 mt-1">User admin</div>
            </button>

            <button 
              onClick={() => alert('Opening archive management for document lifecycle management')}
              className="bg-yellow-500/10 hover:bg-yellow-500/20 border border-yellow-500/30 rounded-xl p-4 transition-all duration-200 group"
            >
              <Archive className="w-8 h-8 text-yellow-400 mx-auto mb-3 group-hover:scale-110 transition-transform" />
              <div className="text-sm font-medium text-white">Archive Docs</div>
              <div className="text-xs text-gray-400 mt-1">Manage archives</div>
            </button>

            <button 
              onClick={() => alert('Opening security console for threat monitoring and incident management')}
              className="bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 rounded-xl p-4 transition-all duration-200 group"
            >
              <Shield className="w-8 h-8 text-red-400 mx-auto mb-3 group-hover:scale-110 transition-transform" />
              <div className="text-sm font-medium text-white">Security</div>
              <div className="text-xs text-gray-400 mt-1">Monitor threats</div>
            </button>

            <button 
              onClick={() => alert('Opening analytics center for detailed reporting and insights')}
              className="bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 rounded-xl p-4 transition-all duration-200 group"
            >
              <BarChart3 className="w-8 h-8 text-cyan-400 mx-auto mb-3 group-hover:scale-110 transition-transform" />
              <div className="text-sm font-medium text-white">Analytics</div>
              <div className="text-xs text-gray-400 mt-1">Deep insights</div>
            </button>
          </div>
        </div>

        {/* Recent Activities Feed */}
        <div className="bg-gray-800/40 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-8 mb-12">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-2xl font-semibold text-white">Recent Activity Feed</h3>
            <button 
              onClick={() => alert('Opening full activity log with filtering and search capabilities')}
              className="text-gray-400 hover:text-gray-300 text-sm font-medium px-4 py-2 bg-gray-500/10 rounded-lg border border-gray-500/30 transition-all"
            >
              View All
            </button>
          </div>

          <div className="space-y-4">
            {[
              { type: 'upload', user: 'john.doe@company.com', action: 'Uploaded 15 documents to HR folder', time: '2 minutes ago', icon: Upload, color: 'blue' },
              { type: 'export', user: 'jane.smith@company.com', action: 'Exported quarterly report (245 pages)', time: '8 minutes ago', icon: Download, color: 'green' },
              { type: 'security', user: 'system', action: 'Security scan completed - No threats detected', time: '15 minutes ago', icon: Shield, color: 'green' },
              { type: 'batch', user: 'admin', action: 'Batch processing job completed (1,250 documents)', time: '23 minutes ago', icon: Package, color: 'purple' },
              { type: 'user', user: 'hr.admin@company.com', action: 'New user account created for marketing team', time: '1 hour ago', icon: User, color: 'cyan' }
            ].map((activity, index) => (
              <div key={index} className="flex items-center gap-4 p-4 bg-white/5 rounded-xl border border-white/10 hover:bg-white/10 transition-all cursor-pointer">
                <div className={`p-2 rounded-lg bg-${activity.color}-500/20 border border-${activity.color}-500/30`}>
                  <activity.icon className={`w-5 h-5 text-${activity.color}-400`} />
                </div>
                <div className="flex-1">
                  <div className="text-white font-medium mb-1">{activity.action}</div>
                  <div className="text-sm text-gray-400">
                    {activity.user} • {activity.time}
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-500" />
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="text-center text-gray-400 text-sm py-8 border-t border-gray-800/50">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <span className="text-lg">© 2025 Document Management System</span>
            <span className="hidden sm:inline text-gray-600">•</span>
            <span>Last updated: {currentTime.toLocaleString()}</span>
            <span className="hidden sm:inline text-gray-600">•</span>
            <button 
              onClick={() => alert('System Health Report:\n\n• Uptime: 99.8%\n• Server Status: Healthy\n• Database: Online\n• Storage: Optimal\n• Network: Stable\n• Last Maintenance: 3 days ago')}
              className="text-green-400 hover:text-green-300 transition-colors font-medium px-3 py-1 bg-green-500/10 rounded-lg border border-green-500/30"
            >
              System Status: Online
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}